import 'dart:io';
import 'package:bazarnicole/Presentation/View/Auth/app_routes.dart';
import 'package:bazarnicole/Presentation/Services/auth_service.dart';
import 'package:bazarnicole/Presentation/Services/database_service.dart';
import 'package:bazarnicole/Presentation/Services/background_job_service.dart';
import 'package:bazarnicole/Presentation/Services/database_maintenance_service.dart';
import 'package:bazarnicole/Presentation/Services/database_config.dart';
import 'package:bazarnicole/Presentation/Services/database_location_service.dart';
import 'package:bazarnicole/Presentation/Utils/Colors.dart';
import 'package:bazarnicole/Presentation/display/database_initializer_native.dart';
import 'package:bazarnicole/Presentation/display/window_manager_initializer.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:bazarnicole/Presentation/Controller/auth_provider.dart';
import 'package:bazarnicole/Presentation/Controller/product_management_controller.dart';
import 'package:bazarnicole/Presentation/Controller/cash_controller.dart';
import 'package:bazarnicole/Presentation/Controller/customers_controller.dart';
import 'package:bazarnicole/Presentation/Controller/pos_controller.dart';
import 'package:bazarnicole/Presentation/Controller/purchases_controller.dart';
import 'package:bazarnicole/Presentation/Controller/reports_controller.dart';
import 'package:bazarnicole/Presentation/Context/providers.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

// Removida la variable global no utilizada que puede causar problemas
// late MyDatabase driftDatabase; // ❌ COMENTADA PARA EVITAR SIGSEGV

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await dotenv.load(fileName: "assets/env.txt");

  // 🌍 INICIALIZAR LOCALIZACIÓN PARA FECHAS
  await initializeDateFormatting('es', null);

  // 🖥️ CONFIGURAR TAMAÑO DE VENTANA PARA DESKTOP
  // Inicializadores por plataforma (nativa / web)
  await initializeWindowManager();
  await initializeDatabasePlatform();

  // 🗄️ INICIALIZAR BASE DE DATOS DE FORMA SEGURA
  await _initDatabaseSafely();

  // 🔄 INICIAR MOTOR DE BACKGROUND JOBS + MANTENIMIENTO (OLAP analytics)
  if (!kIsWeb) {
    final jobService = BackgroundJobService();
    jobService.start();
    await jobService.scheduleDailyMaintenance();

    // 🛠️ Motor de mantenimiento SQLite enterprise (cada 6h)
    DatabaseMaintenanceService().startPeriodicMaintenance(intervalHours: 6);
  }

  // 🌐 Web: siempre muestra el catálogo público, sin autenticación
  if (kIsWeb) {
    runApp(MyApp(initialRoute: AppRoutes.catalog));
    return;
  }

  // 🖥️ Desktop / Móvil: flujo normal con login
  try {
    final authService = AuthService();
    final isLoggedIn = await authService.isLoggedIn();

    final initialRoute = isLoggedIn ? AppRoutes.dashboard : AppRoutes.login;

    runApp(MyApp(initialRoute: initialRoute));
  } catch (e) {
    runApp(MyApp(initialRoute: AppRoutes.login));
  }
}

// 🛡️ INICIALIZACIÓN SEGURA DE BASE DE DATOS
Future<void> _initDatabaseSafely() async {
  if (kIsWeb) return; // Web no usa SQLite local
  try {
    // Para iOS/Android, usar método directo sin servicios complejos
    if (Platform.isIOS || Platform.isAndroid) {
      await _initMobileDatabase();
    } else {
      // Para desktop, usar el DatabaseService normal
      await DatabaseService.database;
    }
  } catch (e) {
    // Intentar método fallback más seguro
    await _safeFallbackDatabaseInit();
  }
}

// 🔧 INICIALIZACIÓN DIRECTA PARA MÓVILES (EVITA SIGSEGV)
Future<void> _initMobileDatabase() async {
  try {
    final dbPath = await DatabaseLocationService.getDatabasePath();

    final File dbFile = File(dbPath);

    // Verificar si existe
    if (!await dbFile.exists()) {
      final ByteData data = await rootBundle.load(DatabaseConfig.assetDbPath);
      final List<int> bytes = data.buffer.asUint8List(
        data.offsetInBytes,
        data.lengthInBytes,
      );

      await dbFile.writeAsBytes(bytes, flush: true);
    }

    // Verificar que se puede abrir
    debugPrint('Opening database:');
    debugPrint(dbPath);

    final db = await openDatabase(dbPath, version: 1, readOnly: false);

    // Cerrar inmediatamente - solo verificamos que funcione
    await db.close();
  } catch (e) {
    rethrow;
  }
}

// 🔧 MÉTODO FALLBACK MEJORADO Y SEGURO

Future<void> _safeFallbackDatabaseInit() async {
  if (kIsWeb) return; // Web no usa SQLite local
  try {
    // Solo para plataformas móviles, usar el método tradicional
    if (Platform.isIOS || Platform.isAndroid) {
      final dbPath = await DatabaseLocationService.getDatabasePath();

      // Verificar si existe y es válida
      final File dbFile = File(dbPath);
      if (await dbFile.exists()) {
        try {
          debugPrint('Opening database:');
          debugPrint(dbPath);

          final db = await openDatabase(
            dbPath,
            readOnly: true, // Solo lectura para verificación
          );
          await db.close();
          return;
        } catch (e) {
          await dbFile.delete();
        }
      }

      // Copiar desde assets solo si es necesario
      try {
        final ByteData data = await rootBundle.load(DatabaseConfig.assetDbPath);
        final List<int> bytes = data.buffer.asUint8List(
          data.offsetInBytes,
          data.lengthInBytes,
        );

        await dbFile.writeAsBytes(bytes, flush: true);

        // Verificar que se puede abrir
        debugPrint('Opening database:');
        debugPrint(dbPath);

        final db = await openDatabase(dbPath);
        await db.close();
      } catch (e) {
        throw Exception('No se pudo inicializar la base de datos');
      }
    }
  } catch (e) {
    // En este punto, la app continuará pero sin base de datos prepoblada
  }
}

class MyApp extends StatelessWidget {
  final String initialRoute;
  const MyApp({super.key, required this.initialRoute});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => ProductManagementController()),
        ChangeNotifierProvider(create: (_) => CashController()),
        ChangeNotifierProvider(create: (_) => PosController()),
        ChangeNotifierProvider(create: (_) => PurchasesController()),
        ChangeNotifierProvider(create: (_) => CustomersController()),
        ChangeNotifierProvider(create: (_) => ReportsController()),
        // Providers de contexto
        ...AppProviders.getProviders(),
      ],
      child: MaterialApp(
        title: 'Bazar & Tienda',
        theme: ThemeData(
          primaryColor: AppColors.primaryLogo,
          useMaterial3: true,
        ),
        initialRoute: initialRoute,
        onGenerateRoute: (settings) {
          final builder = AppRoutes.routes[settings.name];
          if (builder == null) return null;
          return MaterialPageRoute(
            settings: settings,
            builder: (ctx) => SelectionArea(child: builder(ctx)),
          );
        },
        debugShowCheckedModeBanner: false,
        navigatorKey: navigatorKey,
      ),
    );
  }
}
